import numpy as np
import torch
x = np.load('./save_distribution_GT.npy')
print(x.shape)

distribution_GT = torch.from_numpy(x)
print(distribution_GT)
print(distribution_GT.size())
distribution_GT = distribution_GT.to('cuda')
print(distribution_GT)